#ifndef __SYSLOAD_H__
#define __SYSLOAD_H__

void sysLoadInit();

#endif